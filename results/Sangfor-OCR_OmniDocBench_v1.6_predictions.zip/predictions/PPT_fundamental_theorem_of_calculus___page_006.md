After an lot of algebra, it would probably come to an expression similar to this:

\[
\text {Area} = \lim _ {\text {as} h \to 0} 5 6 (1 + 2 h + 4 h ^ {2} + 8 h ^ {3} + \dots)
\]

\[
= 5 6 \text {units} ^ {2}
\]

Unfortunately, simplyfying the expression into something like the above is extremely difficult. (see pages 285 – 288 in my book)