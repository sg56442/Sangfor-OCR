The 65th William Lowell Putnam Mathematical Competition
Saturday, December 4, 2004

A1 Basketball star Shanille O'Keal's team statistician keeps track of the number, \( S(N) \), of successful free throws she has made in her first \( N \) attempts of the season. Early in the season, \( S(N) \) was less than 80% of \( N \), but by the end of the season, \( S(N) \) was more than 80% of \( N \). Was there necessarily a moment in between when \( S(N) \) was exactly 80% of \( N \)?

A2 For \( i = 1,2 \) let \( T_{i} \) be a triangle with side lengths \( a_{i}, b_{i}, c_{i} \), and area \( A_{i} \). Suppose that \( a_{1} \leq a_{2}, b_{1} \leq b_{2}, c_{1} \leq c_{2} \), and that \( T_{2} \) is an acute triangle. Does it follow that \( A_{1} \leq A_{2} \)?

A3 Define a sequence  \( \{u_{n}\}_{n=0}^{\infty} \)  by  \( u_{0}=u_{1}=u_{2}=1 \) , and thereafter by the condition that

\[
\det \left( \begin{array}{c c} u _ {n} & u _ {n + 1} \\ u _ {n + 2} & u _ {n + 3} \end{array} \right) = n!
\]

for all  \( n \geq 0 \) . Show that  \( u_{n} \)  is an integer for all n. (By convention,  \( 0! = 1 \) .)

A4 Show that for any positive integer n there is an integer N such that the product  \( x_{1}x_{2}\cdots x_{n} \)  can be expressed identically in the form

\[
x _ {1} x _ {2} \dots x _ {n} = \sum_ {i = 1} ^ {N} c _ {i} \big (a _ {i 1} x _ {1} + a _ {i 2} x _ {2} + \dots + a _ {i n} x _ {n} \big) ^ {n}
\]

where the  \( c_{i} \)  are rational numbers and each  \( a_{ij} \)  is one of the numbers -1,0,1.

A5 An  \( m \times n \)  checkerboard is colored randomly: each square is independently assigned red or black with probability 1/2. We say that two squares, p and q, are in the same connected monochromatic region if there is a sequence of squares, all of the same color, starting at p and ending at q, in which successive squares in the sequence share a common side. Show that the expected number of connected monochromatic regions is greater than mn/8.

A6 Suppose that \( f(x,y) \) is a continuous real-valued function on the unit square \( 0 \leq x \leq 1, 0 \leq y \leq 1 \). Show that

\[
\int_ {0} ^ {1} \left(\int_ {0} ^ {1} f (x, y) d x\right) ^ {2} d y + \int_ {0} ^ {1} \left(\int_ {0} ^ {1} f (x, y) d y\right) ^ {2} d x
\]

\[
\leq \left(\int_ {0} ^ {1} \int_ {0} ^ {1} f (x, y) d x d y\right) ^ {2} + \int_ {0} ^ {1} \int_ {0} ^ {1} [ f (x, y) ] ^ {2} d x d y.
\]

B1 Let  \( P(x) = c_{n}x^{n} + c_{n-1}x^{n-1} + \cdots + c_{0} \)  be a polynomial with integer coefficients. Suppose that r is a rational number such that  \( P(r) = 0 \) . Show that the n numbers

\[
c _ {n} r, c _ {n} r ^ {2} + c _ {n - 1} r, c _ {n} r ^ {3} + c _ {n - 1} r ^ {2} + c _ {n - 2} r,
\]

\[
\dots , c _ {n} r ^ {n} + c _ {n - 1} r ^ {n - 1} + \dots + c _ {1} r
\]

are integers.

B2 Let \( m \) and \( n \) be positive integers. Show that

\[
\frac {(m + n) !}{(m + n) ^ {m + n}} <   \frac {m !}{m ^ {m}} \frac {n !}{n ^ {n}}.
\]

B3 Determine all real numbers \( a > 0 \) for which there exists a nonnegative continuous function \( f(x) \) defined on \( [0, a] \) with the property that the region

\[
R = \{(x, y); 0 \leq x \leq a, 0 \leq y \leq f (x) \}
\]

has perimeter \( k \) units and area \( k \) square units for some real number \( k \).

B4 Let \( n \) be a positive integer, \( n \geq 2 \), and put \( \theta = 2\pi / n \). Define points \( P_k = (k, 0) \) in the \( xy \)-plane, for \( k = 1, 2, \dots, n \). Let \( R_k \) be the map that rotates the plane counterclockwise by the angle \( \theta \) about the point \( P_k \). Let \( R \) denote the map obtained by applying, in order, \( R_1 \), then \( R_2, \dots \), then \( R_n \). For an arbitrary point \( (x, y) \), find, and simplify, the coordinates of \( R(x, y) \).

B5 Evaluate

\[
\lim _ {x \to 1 ^ {-}} \prod_ {n = 0} ^ {\infty} \left(\frac {1 + x ^ {n + 1}}{1 + x ^ {n}}\right) ^ {x ^ {n}}.
\]

B6 Let A be a non-empty set of positive integers, and let  \( N(x) \)  denote the number of elements of A not exceeding x. Let B denote the set of positive integers b that can be written in the form  \( b = a - a' \)  with  \( a \in A \)  and  \( a' \in A \) . Let  \( b_{1} < b_{2} < \cdots \)  be the members of B, listed in increasing order. Show that if the sequence  \( b_{i+1} - b_{i} \)  is unbounded, then

\[
\lim _ {x \to \infty} N (x) / x = 0.
\]