The 55th William Lowell Putnam Mathematical Competition
Saturday, December 3, 1994

A-1 Suppose that a sequence \( a_1, a_2, a_3, \ldots \) satisfies \( 0 < a_n \leq a_{2n} + a_{2n+1} \) for all \( n \geq 1 \). Prove that the series \( \sum_{n=1}^{\infty} a_n \) diverges.

A-2 Let \( A \) be the area of the region in the first quadrant bounded by the line \( y = \frac{1}{2} x \), the \( x \)-axis, and the ellipse \( \frac{1}{9} x^2 + y^2 = 1 \). Find the positive number \( m \) such that \( A \) is equal to the area of the region in the first quadrant bounded by the line \( y = mx \), the \( y \)-axis, and the ellipse \( \frac{1}{9} x^2 + y^2 = 1 \).

A–3 Show that if the points of an isosceles right triangle of side length 1 are each colored with one of four colors, then there must be two points of the same color which are at least a distance \(2 - \sqrt{2}\) apart.

A-4 Let \( A \) and \( B \) be \( 2 \times 2 \) matrices with integer entries such that \( A, A + B, A + 2B, A + 3B \), and \( A + 4B \) are all invertible matrices whose inverses have integer entries. Show that \( A + 5B \) is invertible and that its inverse has integer entries.

A-5 Let \((r_n)_{n\geq 0}\) be a sequence of positive real numbers such that \(\lim_{n\to \infty}r_n = 0\). Let \(S\) be the set of numbers representable as a sum

\[
r _ {i _ {1}} + r _ {i _ {2}} + \dots + r _ {i _ {1 9 9 4}},
\]

with  \( i_{1} < i_{2} < \cdots < i_{1994} \) . Show that every nonempty interval  \( (a, b) \)  contains a nonempty subinterval  \( (c, d) \)  that does not intersect S.

A–6 Let \( f_1, \ldots, f_{10} \) be bijections of the set of integers such that for each integer \( n \), there is some composition \( f_{i_1} \circ f_{i_2} \circ \cdots \circ f_{i_m} \) of these functions (allowing repetitions) which maps 0 to \( n \). Consider the set of 1024 functions

\[
\mathcal {F} = \{f _ {1} ^ {e _ {1}} \circ f _ {2} ^ {e _ {2}} \circ \dots \circ f _ {1 0} ^ {e _ {1 0}} \},
\]

\( e_{i}=0 \) or 1 for \( 1\leq i\leq10 \). ( \( f_{i}^{0} \) is the identity function and \( f_{i}^{1}=f_{i.} \) ) Show that if A is any nonempty finite set

of integers, then at most 512 of the functions in \(\mathcal{F}\) map \(A\) to itself.

B-1 Find all positive integers \( n \) that are within 250 of exactly 15 perfect squares.

B-2 For which real numbers \( c \) is there a straight line that intersects the curve

\[
x ^ {4} + 9 x ^ {3} + c x ^ {2} + 9 x + 4
\]

in four distinct points?

B-3 Find the set of all real numbers \( k \) with the following property: For any positive, differentiable function \( f \) that satisfies \( f'(x) > f(x) \) for all \( x \), there is some number \( N \) such that \( f(x) > e^{kx} \) for all \( x > N \).

B-4 For \( n \geq 1 \), let \( d_{n} \) be the greatest common divisor of the entries of \( A^{n} - I \), where

\[
A = \left( \begin{array}{c c} 3 & 2 \\ 4 & 3 \end{array} \right) \quad \text {and} \quad I = \left( \begin{array}{c c} 1 & 0 \\ 0 & 1 \end{array} \right).
\]

Show that \(\lim_{n\to \infty}d_n = \infty\).

B-5 For any real number \(\alpha\), define the function \(f_{\alpha}(x) = \lfloor \alpha x \rfloor\). Let \(n\) be a positive integer. Show that there exists an \(\alpha\) such that for \(1 \leq k \leq n\),

\[
f _ {\alpha} ^ {k} (n ^ {2}) = n ^ {2} - k = f _ {\alpha^ {k}} (n ^ {2}).
\]

B-6 For any integer \(n\), set

\[
n _ {a} = 1 0 1 a - 1 0 0 \cdot 2 ^ {a}.
\]

Show that for \(0 \leq a, b, c, d \leq 99\), \(n_a + n_b \equiv n_c + n_d\) (mod 10100) implies \(\{a, b\} = \{c, d\}\).