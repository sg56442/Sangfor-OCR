306

\(2,855~\mathrm{cm}^{-1}\). \({}^{1}\mathrm{H}\) NMR(CDCl₃): \(\mathrm{CH}_2 = 6.3947\), \(6.2463\); \(=\mathrm{CH}\) 5.7740; NH 7.2239; benzyl- \(\mathrm{CH}_2\) 7.1266, 7.4601; \(\mathrm{CH}_3\) 0.9177; \(\mathrm{CH}_3\)- \(\mathrm{CH}_2\) 1.3244; \(\mathrm{CH}_3\)- \(\mathrm{CH}_2\)- \(\mathrm{CH}_2\) 1.5782; \(\mathrm{CH}_3\)- \(\mathrm{CH}_2\)- \(\mathrm{CH}_2\)- \(\mathrm{CH}_2\)- 2.5798.

Polymer synthesis

A micellar polymerization technique was used to prepare polymers using sodium dodecyl sulfate (SDS) as the surfactant and potassium persulfate as the free-radical initiator  \( [6] \) . The appropriate amount of ionizable monomer (AA) was dissolved in deionized water and the pH was adjusted to 9–10 with NaOH to form the water-soluble sodium salt (sodium acrylate). AM, BPAM, and SDS were added respectively, and stirred under  \( N_{2} \)  until a clear solution was observed. The solution was then heated to 50 °C, and the initiator was added. The polymerization was conducted for 12 h. The polymer mixtures were diluted with water and precipitated into acetone and then washed with acetone. The polymer was dried under reduced pressure at 40 °C for 4 h. The polymers (abbreviation APA-n, Scheme 1) used in this study are listed in Table 1.

Scheme 1

viscosification of the copolymers [5]. In this work, the polyelectrolyte poly[acrylamide–acrylic acid–N-(4-butyl)phenylacrylamide] [P(AM–AA–BPAM)] was synthesized. The rheological properties were investigated in more detailed. Pyrene probe fluorescence, dynamic light scattering, and atom force microscopy (AFM) were used to explore the conformational behaviors which are dependent on the electrostatic and hydrophobic interactions.

Experimental

Materials and synthesis of monomers and polymers

AM, 4-butylaniline, was purchased from Fluka Chemical Co. and was used as received. AA was purified by recrystallization from deionized water.

Monomer synthesis

BPAM was synthesized from the reaction of 4-butylaniline with acryloyl chloride, with triethylamine as the acid receptor, using the method described by McCormick et al. [6]. The crude product was recrystallized twice from ethanol at \(-25^{\circ}\mathrm{C}\) and a white product obtained. The melting point was \(92 - 93^{\circ}\mathrm{C}\). FTIR (KBr): \(\mathrm{C = C - H}\) 3,079, \(3,029~\mathrm{cm}^{-1}\); N-H \(3,283~\mathrm{cm}^{-1}\); \(\mathrm{C = C}\) \(1,636~\mathrm{cm}^{-1}\); \(\mathrm{C = O}\) \(1,662~\mathrm{cm}^{-1}\); phenol \(1,608~\mathrm{cm}^{-1}\); \(\mathrm{CH}_3\) 2,952, \(2,870~\mathrm{cm}^{-1}\); \(\mathrm{CH}_2\) 2,927,

Measurements

Elemental analysis was performed with a Elementar-CHNO-Rapiol to determine the carbon, nitrogen, and hydrogen content. The Fourier transform IR measurement was conducted using a Biorad/ Digilab FTS40, and the  \( {}^{1} \) H NMR measurements were carried out on the BPAM solution in CDCl \( _{3} \)  using a Bruker Ac250. UV spectra were obtained with a Spektralphotometer DMR 10. Pyrene fluorescence studies were performed with a Shimadzu RF-5301 PC spectrofluorophotometer ( \( \lambda_{EX} = 335 \)  nm,  \( I_{1} = 373 \)  nm,  \( I_{2} = 384 \)  nm). Viscosity measurements and oscillatory rheological measurements were conducted with a Bohlin CS rheometer with a cone/plate or double-gap concentric cylinder measuring geometry with a cone angle of 4° and a diameter of 40 mm. The double-gap device is applicable for low-viscosity liquids. The zero-shear viscosity in dilute solution was measured with a Paar OCR-D oscillating capillary rheometer. The measurement temperature was 25 °C, and shear rate was 6 s \( ^{-1} \)  unless otherwise noted. The atom force electron micrographs were made using a Digital Instruments Nanoscope III controller with a Dimension 3100 microscope, and all measurements were performed in tapping mode. Mica wafers were employed as the substrate for the measurements and the sample was prepared by dip-coating and drying up. Dynamic light scattering studies were performed at 60–120° and the signals were processed with a Brookhaven Instruments BI-2030AT autocorrelator. Effective hydrodynamic diameters were calculated using the algorithm CONTIN and associated software.

Table 1 Synthesis parameters of APA terpolymers

<table><tr><td>Sample</td><td>Acrylamide concentration (mol%)</td><td>Acrylic acid concentration (mol%)</td><td>N-(4-Butyl) phenylacrylamide concentration (mol%)</td><td>Monomer concentration (%)</td><td>Initiator concentration (mol%)</td><td>Sodium dodecyl sulfate concentration (%)</td><td>Temperature (°C)</td></tr><tr><td>APA-0</td><td>75</td><td>25</td><td>0</td><td>8</td><td>0.5</td><td>0</td><td>50</td></tr><tr><td>APA-1</td><td>84.5</td><td>15</td><td>0.5</td><td>8</td><td>0.5</td><td>7</td><td>50</td></tr><tr><td>APA-2</td><td>84.5</td><td>15</td><td>0.5</td><td>8</td><td>0.5</td><td>3.25</td><td>50</td></tr><tr><td>APA-3</td><td>84.5</td><td>15</td><td>0.5</td><td>8</td><td>0.5</td><td>2.2</td><td>50</td></tr><tr><td>APA-4</td><td>84.5</td><td>15</td><td>0.5</td><td>8</td><td>0.5</td><td>1.5</td><td>50</td></tr><tr><td>APA-5</td><td>74.5</td><td>25</td><td>0.5</td><td>8</td><td>0.5</td><td>1.5</td><td>50</td></tr><tr><td>APA-6</td><td>74.5</td><td>25</td><td>0.5</td><td>8</td><td>0.5</td><td>3.25</td><td>50</td></tr><tr><td>APA-7</td><td>94.5</td><td>5</td><td>0.5</td><td>8</td><td>0.5</td><td>3.25</td><td>50</td></tr></table>