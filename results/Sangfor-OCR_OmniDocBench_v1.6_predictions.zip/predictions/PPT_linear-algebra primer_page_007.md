Projection: Using Inner Products (I)

Projection of x along the direction \(\mathbf{a}\) (\(\| \mathbf{a} \| = 1\)).

\[
\mathbf {p} = \mathbf {a} \left(\mathrm{a} ^ {\mathrm{T}} \mathrm{x}\right)
\]

\[
\left\| \mathbf {a} \right\| = \mathbf {a} ^ {\mathrm{T}} \mathbf {a} = 1
\]

Rensselaer Polytechnic Institute

Shivkumar Kalyanaraman

7

Google": "shiv rpi"