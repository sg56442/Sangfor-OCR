Generally, this is what we could do:

Area of 1 rectangle \(\approx f(x) \times h\)

Area of all the rectangles ≈ ∑ f(x) × h

Actual area under the curve = lim \(\sum_{h\to 0}f(x)\times h\)

which is written as \(\int f(x) dx\)

( but evaluating this limit is incredibly complicated)