7.2 Matrix Multiplication

If all the diagonal entries of a diagonal matrix S are equal, say, c, we call S a scalar matrix because multiplication of any square matrix A of the same size by S has the same effect as the multiplication by a scalar, that is,

\[
\mathbf {A} \mathbf {S} = \mathbf {S} \mathbf {A} = c \mathbf {A}. 
\]

In particular, a scalar matrix, whose entries on the main diagonal are all 1, is called a unit matrix (or identity matrix) and is denoted by \(\mathbf{I}_n\) or simply by \(\mathbf{I}\). For \(\mathbf{I}\), formula (12) becomes

\[
\mathbf {A I} = \mathbf {I A} = \mathbf {A}. 
\]

Section 7.2 p30

Advanced Engineering Mathematics, 10/e by Edwin Kreyszig Copyright 2011 by John Wiley & Sons. All rights reserved.