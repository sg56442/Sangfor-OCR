项目 4 综合应用

续表

<table><tr><td rowspan="2">序号</td><td rowspan="2">监控内容</td><td rowspan="2">连接变量</td><td colspan="2">输入值</td><td colspan="3">输出值</td></tr><tr><td>数值类型</td><td>数值范围</td><td>数值类型</td><td>整数位数</td><td>小数位数</td></tr><tr><td>3</td><td>操作值</td><td>MV</td><td></td><td></td><td>模拟量输出</td><td>3位</td><td>2位</td></tr><tr><td>4</td><td>手动设定值</td><td>SP_man</td><td>模拟量输入</td><td>0~100</td><td>模拟量输出</td><td>3位</td><td>2位</td></tr><tr><td>5</td><td>PID比例系数</td><td>PID0_P</td><td>模拟量输入</td><td>0~100</td><td>模拟量输出</td><td>3位</td><td>2位</td></tr><tr><td>6</td><td>PID积分时间</td><td>PID0_I</td><td>模拟量输入</td><td>0~100</td><td>模拟量输出</td><td>3位</td><td>2位</td></tr><tr><td>7</td><td>PID微分时间</td><td>PID0_D</td><td>模拟量输入</td><td>0~100</td><td>模拟量输出</td><td>3位</td><td>2位</td></tr><tr><td>8</td><td>控制方式</td><td>MAN_on</td><td>离散值输入</td><td>0或1</td><td>离散值输出</td><td></td><td></td></tr></table>

图 4.75 实时趋势曲线标识定义——设置坐标轴

图 4.76 监控主界面

134