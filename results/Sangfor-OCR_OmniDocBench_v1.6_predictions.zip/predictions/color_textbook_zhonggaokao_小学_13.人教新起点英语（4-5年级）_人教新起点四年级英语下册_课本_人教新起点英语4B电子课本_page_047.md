Lesson 3

A Read and write.

This is my family's hobby book. I like collecting stamps. 📄 I have over 200

stamps. I also like skateboarding. I think it is very cool. My mother likes drawing. She is really good at it. My father likes fishing. He often goes fishing but never catches any fish. My cat likes eating fish. She often goes with my father, but she never gets any fish!

B Read again and write.

Bob likes ________________.

His mother likes ______________.

His father likes ______________.

His cat likes ________________.

I like ______________.

My ________________ ________________ ________________

42