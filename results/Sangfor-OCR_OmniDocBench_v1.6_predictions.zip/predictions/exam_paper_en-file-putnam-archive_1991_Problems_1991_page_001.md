The 52nd William Lowell Putnam Mathematical Competition
Saturday, December 7, 1991

A-1 A \(2 \times 3\) rectangle has vertices as \((0,0)\), \((2,0)\), \((0,3)\), and \((2,3)\). It rotates \(90^{\circ}\) clockwise about the point \((2,0)\). It then rotates \(90^{\circ}\) clockwise about the point \((5,0)\), then \(90^{\circ}\) clockwise about the point \((7,0)\), and finally, \(90^{\circ}\) clockwise about the point \((10,0)\). (The side originally on the \(x\)-axis is now back on the \(x\)-axis.) Find the area of the region above the \(x\)-axis and below the curve traced out by the point whose initial position is \((1,1)\).

A-2 Let \(\mathbf{A}\) and \(\mathbf{B}\) be different \(n \times n\) matrices with real entries. If \(\mathbf{A}^3 = \mathbf{B}^3\) and \(\mathbf{A}^2\mathbf{B} = \mathbf{B}^2\mathbf{A}\), can \(\mathbf{A}^2 + \mathbf{B}^2\) be invertible?

A-3 Find all real polynomials \( p(x) \) of degree \( n \geq 2 \) for which there exist real numbers \( r_1 < r_2 < \dots < r_n \) such that

1. \(p(r_{i}) = 0\), \(\quad i = 1,2,\dots,n\), and

2. \(p^{\prime}\left(\frac{r_{i} + r_{i + 1}}{2}\right) = 0 \quad i = 1,2,\dots ,n - 1,\)

where  \( p'(x) \)  denotes the derivative of  \( p(x) \) .

A-4 Does there exist an infinite sequence of closed discs \( D_{1}, D_{2}, D_{3}, \ldots \) in the plane, with centers \( c_{1}, c_{2}, c_{3}, \ldots \), respectively, such that

1. the \(c_{i}\) have no limit point in the finite plane,

2. the sum of the areas of the \(D_{i}\) is finite, and

3. every line in the plane intersects at least one of the \(D_{i}\)?

A-5 Find the maximum value of

\[
\int_ {0} ^ {y} \sqrt {x ^ {4} + (y - y ^ {2}) ^ {2}} d x
\]

for \(0 \leq y \leq 1\).

A-6 Let \( A(n) \) denote the number of sums of positive integers

\[
a _ {1} + a _ {2} + \dots + a _ {r}
\]

which add up to \( n \) with

\[
a _ {1} > a _ {2} + a _ {3}, a _ {2} > a _ {3} + a _ {4}, \dots ,
\]

\[
a _ {r - 2} > a _ {r - 1} + a _ {r}, a _ {r - 1} > a _ {r}.
\]

Let \( B(n) \) denote the number of \( b_{1} + b_{2} + \cdots + b_{s} \) which add up to n, with

1. \(b_{1} \geq b_{2} \geq \dots \geq b_{s}\),

2. each \( b_{i} \) is in the sequence \( 1, 2, 4, \ldots, g_{j}, \ldots \) defined by \( g_{1} = 1 \), \( g_{2} = 2 \), and \( g_{j} = g_{j-1} + g_{j-2} + 1 \), and

3. if \( b_{1} = g_{k} \) then every element in \( \{1,2,4,\dots,g_{k}\} \) appears at least once as a \( b_{i} \). Prove that \( A(n) = B(n) \) for each \( n \geq 1 \).

(For example, \( A(7) = 5 \) because the relevant sums are \( 7,6 + 1,5 + 2,4 + 3,4 + 2 + 1 \), and \( B(7) = 5 \) because the relevant sums are \( 4 + 2 + 1,2 + 2 + 2 + 1,2 + 2 + 1 + 1 + 1,2 + 1 + 1 + 1 + 1 + 1,1 + 1 + 1 + 1 + 1 + 1 + 1 + 1. \))

B-1 For each integer \( n \geq 0 \), let \( S(n) = n - m^2 \), where \( m \) is the greatest integer with \( m^2 \leq n \). Define a sequence \( (a_k)_{k=0}^\infty \) by \( a_0 = A \) and \( a_{k+1} = a_k + S(a_k) \) for \( k \geq 0 \). For what positive integers \( A \) is this sequence eventually constant?

B-2 Suppose \( f \) and \( g \) are non-constant, differentiable, real-valued functions defined on \( (-\infty, \infty) \). Furthermore, suppose that for each pair of real numbers \( x \) and \( y \),

\[
f (x + y) = f (x) f (y) - g (x) g (y),
\]

\[
g (x + y) = f (x) g (y) + g (x) f (y).
\]

If \( f'(0) = 0 \), prove that \( (f(x))^2 + (g(x))^2 = 1 \) for all \( x \).

B-3 Does there exist a real number \( L \) such that, if \( m \) and \( n \) are integers greater than \( L \), then an \( m \times n \) rectangle may be expressed as a union of \( 4 \times 6 \) and \( 5 \times 7 \) rectangles, any two of which intersect at most along their boundaries?

B-4 Suppose \( p \) is an odd prime. Prove that

\[
\sum_ {j = 0} ^ {p} \binom {p} {j} \binom {p + j} {j} \equiv 2 ^ {p} + 1 \pmod {p ^ {2}}.
\]

B-5 Let \( p \) be an odd prime and let \( \mathbb{Z}_p \) denote (the field of) integers modulo \( p \). How many elements are in the set

\[
\{x ^ {2}: x \in \mathbb {Z} _ {p} \} \cap \{y ^ {2} + 1: y \in \mathbb {Z} _ {p} \}?
\]

B-6 Let \( a \) and \( b \) be positive numbers. Find the largest number \( c \), in terms of \( a \) and \( b \), such that

\[
a ^ {x} b ^ {1 - x} \leq a \frac {\sinh u x}{\sinh u} + b \frac {\sinh u (1 - x)}{\sinh u}
\]

for all \( u \) with \( 0 < |u| \leq c \) and for all \( x \), \( 0 < x < 1 \). (Note: \( \sinh u = (e^u - e^{-u}) / 2 \).)