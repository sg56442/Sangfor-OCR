The Quotient Rule

SO

\[
\frac {d}{d x} \bigg (\frac {u}{v} \bigg) = \lim _ {\Delta x \to 0} \frac {\Delta (u / v)}{\Delta x} = \lim _ {\Delta x \to 0} \frac {v \frac {\Delta u}{\Delta x} - u \frac {\Delta v}{\Delta x}}{v (v + \Delta v)}
\]

As \( \Delta x \rightarrow 0 \), \( \Delta v \rightarrow 0 \) also, because \( v = g(x) \) is differentiable and therefore continuous.

Thus, using the Limit Laws, we get

\[
\frac {d}{d x} \left(\frac {u}{v}\right) = \frac {v \lim _ {\Delta x \to 0} \frac {\Delta u}{\Delta x} - u \lim _ {\Delta x \to 0} \frac {\Delta v}{\Delta x}}{v \lim _ {\Delta x \to 0} (v + \Delta v)} = \frac {v \frac {d u}{d x} - u \frac {d v}{d x}}{v ^ {2}}
\]

15