\[
1 5. \left[\begin{array}{c c c c c}1&- 6&0&0&5\\0&1&- 4&1&0\\- 1&6&1&5&3\\0&- 1&5&4&0\end{array}\right]\rightarrow \left[\begin{array}{c c c c c}1&- 6&0&0&5\\0&1&- 4&1&0\\0&0&1&5&8\\0&- 1&5&4&0\end{array}\right]\rightarrow
\]

\[
\left[\begin{array}{c c c c c}1&- 6&0&0&5\\0&1&- 4&1&0\\0&0&1&5&8\\0&0&1&5&0\end{array}\right]\rightarrow \left[\begin{array}{c c c c c}1&- 6&0&0&5\\0&1&- 4&1&0\\0&0&1&5&8\\0&0&0&0&- 8\end{array}\right] \text {inconsistent}
\]