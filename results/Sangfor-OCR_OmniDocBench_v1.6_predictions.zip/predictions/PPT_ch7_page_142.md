(continued 3)

SUMMARY OF CHAPTER 7

Linear Algebra: Matrices, Vectors, Determinants. Linear Systems

The transpose \(\mathbf{A}^{\top}\) of a matrix \(\mathbf{A} = [a_{jk}]\) is \(\mathbf{A}^{\top} = [a_{jk}]\); rows become columns and conversely (Sec. 7.2). Here, \(\mathbf{A}\) need not be square. If it is and \(\mathbf{A} = \mathbf{A}^{\top}\), then \(\mathbf{A}\) is called symmetric; if \(\mathbf{A} = -\mathbf{A}^{\top}\), it is called skew-symmetric.

For a product,  \( (\mathbf{AB})^{\mathrm{T}} = \mathbf{B}^{\mathrm{T}}\mathbf{A}^{\mathrm{T}} \)  (Sec. 7.2).

A main application of matrices concerns linear systems of equations

\[
\mathbf {A} \mathbf {x} = \mathbf {b}  
\]

(m equations in n unknowns  \( x_{1}, \ldots, x_{n} \) ; A and b given).

Section 7.Summary p142

Advanced Engineering Mathematics, 10/e by Edwin Kreyszig Copyright 2011 by John Wiley & Sons. All rights reserved.