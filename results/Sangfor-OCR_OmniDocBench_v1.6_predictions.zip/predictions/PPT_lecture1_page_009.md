\[
x _ {1} \quad - 2 x _ {2} \quad + x _ {3} \quad = 0
\]

\[
2 x _ {2} \quad - 8 x _ {3} \quad = 8
\]

\[
\begin{array}{r l r} - 3 x _ {2} & + 1 3 x _ {3} & = - 9 \end{array}
\]

\[
\left[ \begin{array}{c c c c} 1 & - 2 & 1 & 0 \\ 0 & 2 & - 8 & 8 \\ 0 & - 3 & 1 3 & - 9 \end{array} \right]
\]

Changing the coefficient of \(x_{2}\) from 2 to 1.

- The purpose of this step is to simplify the calculation in the next steps.

- To do it, we multiply the \(2^{nd}\) equation by \(1/2\).

\[
x _ {1} \quad - 2 x _ {2} \quad + x _ {3} \quad = 0
\]

\[
x _ {2} \quad - 4 x _ {3} \quad = 4
\]

\[
\begin{array}{r l r} - 3 x _ {2} & + 1 3 x _ {3} & = - 9 \end{array}
\]

\[
\left[ \begin{array}{c c c c} 1 & - 2 & 1 & 0 \\ 0 & 1 & - 4 & 4 \\ 0 & - 3 & 1 3 & - 9 \end{array} \right]
\]