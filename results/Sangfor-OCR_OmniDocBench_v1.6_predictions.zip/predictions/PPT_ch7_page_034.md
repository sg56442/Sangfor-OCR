7.3 Linear Systems of Equations. Gauss Elimination

Matrix Form of the Linear System (1).

From the definition of matrix multiplication we see that the m equations of (1) may be written as a single vector equation

\[
\mathbf {A} \mathbf {x} = \mathbf {b} 
\]

where the coefficient matrix \(\mathbf{A} = [a_{jk}]\) is the \(m \times n\) matrix

\[
\mathbf {A} = \left[ \begin{array}{c c c c} a _ {1 1} & a _ {1 2} & \dots & a _ {1 n} \\ a _ {2 1} & a _ {2 2} & \dots & a _ {2 n} \\ . & . & \dots & . \\ a _ {m 1} & a _ {m 2} & \dots & a _ {m n} \end{array} \right], \quad \text {and} \quad \mathbf {x} = \left[ \begin{array}{c} x _ {1} \\ . \\ . \\ . \\ x _ {n} \end{array} \right] \quad \text {and} \quad \mathbf {b} = \left[ \begin{array}{c} b _ {1} \\ \vdots \\ b _ {m} \end{array} \right]
\]

are column vectors.

Section 7.3 p34

Advanced Engineering Mathematics, 10/e by Edwin Kreyszig Copyright 2011 by John Wiley & Sons. All rights reserved.