7.9 Vector Spaces, Inner Product

Spaces, Linear Transformations Optional

Vectors whose inner product is zero are called orthogonal. The length or norm of a vector in V is defined by

\[
\| \mathbf {a} \| = \sqrt {(\mathbf {a} , \mathbf {a})} \quad (\geq 0). 
\]

A vector of norm 1 is called a unit vector. From these axioms and from (2) one can derive the basic inequality

\[
\| \mathbf {a}, \mathbf {b} \| \leq \| \mathbf {a} \| \| \mathbf {b} \| \quad \text {(Cauchy - Schwarz inequality)} 
\]

From this follows

\[
\| \mathbf {a} + \mathbf {b} \| \leq \| \mathbf {a} \| + \| \mathbf {b} \| \quad (T r i a n g l e i n e q u a l i t y). 
\]

A simple direct calculation gives

\[
\left\| \mathbf {a} + \mathbf {b} \right\| ^ {2} + \left\| \mathbf {a} - \mathbf {b} \right\| ^ {2} = 2 (\left\| \mathbf {a} \right\| ^ {2} + \left\| \mathbf {b} \right\| ^ {2}) \quad (P a r a l l e l o g r a m e q u a l i t y). 
\]

Section 7.9 p132

Advanced Engineering Mathematics, 10/e by Edwin Kreyszig Copyright 2011 by John Wiley & Sons. All rights reserved.