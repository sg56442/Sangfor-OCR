7.3 Linear Systems of Equations. Gauss Elimination

At the end of the Gauss elimination (before the back substitution), the row echelon form of the augmented matrix will be

(9)

\[
\left[ \begin{array}{ccccc} r _ {1 1} & r _ {1 2} & \cdots & \cdots & \cdots & r _ {1 n} & f _ {1} \\ \hline & r _ {2 2} & \cdots & \cdots & \cdots & r _ {2 n} & f _ {2} \\ & & \ddots & \cdots & \cdots & \vdots & \vdots \\ & & & r _ {r r} & \cdots & r _ {r n} & f _ {r} \\ \hline \end{array} \right]\quad \begin{array}{c} f _ {r + 1} \\ \vdots \\ f _ {m} \end{array}
\]

Here, and all entries in the blue triangle and blue rectangle are zero.

Section 7.3 p53

Advanced Engineering Mathematics, 10/e by Edwin Kreyszig

Copyright 2011 by John Wiley & Sons. All rights reserved.