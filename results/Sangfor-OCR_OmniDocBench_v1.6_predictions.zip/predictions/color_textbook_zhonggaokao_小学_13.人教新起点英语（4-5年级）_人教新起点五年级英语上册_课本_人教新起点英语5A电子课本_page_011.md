Let's Spell

A Listen, point and repeat.

B Listen, colour and repeat.

1. cl
bl ock

2.  \( \boxed{bl} \)   ue

3. \(\frac{\mathrm{cl}}{\mathrm{gl}}\) ass

4. \( \frac{sl}{fl} \) OW

5. \(\begin{array}{c}\boxed{\mathrm{fl}}\\ \boxed{\mathrm{sl}}\end{array}\mathbf{y}\)

6. \(\begin{array}{c}\mathrm{pl}\\ \mathrm{cl}\end{array}\) ay

7. \(\boxed{\begin{array}{c}\mathrm{sl}\\ \mathrm{pl}\end{array}}\) ant

8. gl ide
sl

© Listen, write and say.

Ms ____ is slim. She wears ____. Her gloves are ____.

D Listen and repeat.

My little blue plane
Is flying in the sky.
It flies very slowly,
But it climbs up high.

8