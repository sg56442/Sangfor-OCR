2018年广西北部湾经济区初中学业水平统一考试

英语

笔试部分

二.单项选择

从下列每小题所给的 A、B、C、D 四个选项中，选出可以填入空白处的最佳选项，并在答题卡上将选定答案的字母标号涂黑。

1. ——Happy New Year!

A. That's OK.

B. The same to you.

C. It doesn't matter.

D. You're welcome.

2. My uncle works in a hospital. He is a/an ____.

A. singer

B. farmer

C. actor

D. doctor

3. The strawberries ____ delicious. You can have a try.

A. eat

B. drink

C. taste

D. sound

4. Tony always works hard. Of all the students, he did ____ in this exam.

A. good

B. well

C. better

D. best

5. Don't worried. This girl is old enough to look after____.

A. herself

B. her

C. hers

D. she

6. ____ the map and tell me where Shanghai is.

A. Look around

B. Look like

C. Look at

D. Look out

7. ——Is this your camera?

——Yes, I ____ it for two weeks.

A. bought

B. had

C. have had

D. have bought

8. The woman in a hat is ____ aunt.

A. Jack and John

B. Jack's and John

C. Jack's and John's

D. Jack and John's

9. Our teacher often tells us ____ in the river. It's dangerous.

A. not swim

B. not to swim

C. to swim

D. swimming

10. As soon as she ____ in Nanning, she will call you.

A. arrives

B. arrive

C. will arrive

D. arrived

三．完形填空

阅读下面短文，掌握其大意，然后从各题所给的 A、B、C、D 四个选项中 选出最佳选项，