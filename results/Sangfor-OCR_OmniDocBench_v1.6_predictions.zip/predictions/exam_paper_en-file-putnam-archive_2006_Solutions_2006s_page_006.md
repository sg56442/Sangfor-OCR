6

Zaslavsky, Extremal arrangements of hyperplanes, Ann. N. Y. Acad. Sci. 440 (1985), 69-87.

B-4 The maximum is \(2^{k}\), achieved for instance by the subspace

\[
\{(x _ {1}, \dots , x _ {n}) \in \mathbb {R} ^ {n}: x _ {1} = \dots = x _ {n - k} = 0 \}.
\]

First solution: More generally, we show that any affine k-dimensional plane in  \( R^{n} \)  can contain at most  \( 2^{k} \)  points in Z. The proof is by induction on  \( k + n \) ; the case k = n = 0 is clearly true.

Suppose that \( V \) is a \( k \)-plane in \( \mathbb{R}^n \). Denote the hyperplanes \( \{x_n = 0\} \) and \( \{x_n = 1\} \) by \( V_0 \) and \( V_1 \), respectively. If \( V \cap V_0 \) and \( V \cap V_1 \) are each at most \( (k - 1) \)-dimensional, then \( V \cap V_0 \cap Z \) and \( V \cap V_1 \cap Z \) each have cardinality at most \( 2^{k-1} \) by the induction assumption, and hence \( V \cap Z \) has at most \( 2^k \) elements. Otherwise, if \( V \cap V_0 \) or \( V \cap V_1 \) is \( k \)-dimensional, then \( V \subset V_0 \) or \( V \subset V_1 \); now apply the induction hypothesis on \( V \), viewed as a subset of \( \mathbb{R}^{n-1} \) by dropping the last coordinate.

Second solution: Let S be a subset of Z contained in a k-dimensional subspace of V. This is equivalent to asking that any  \( t_{1},\ldots,t_{k+1}\in S \)  satisfy a nontrivial linear dependence  \( c_{1}t_{1}+\cdots+c_{k+1}t_{k+1}=0 \)  with  \( c_{1},\ldots,c_{k+1}\in R \) . Since  \( t_{1},\ldots,t_{k+1}\in Q^{n} \) , given such a dependence we can always find another one with  \( c_{1},\ldots,c_{k+1}\in Q \) ; then by clearing denominators, we can find one with  \( c_{1},\ldots,c_{k+1}\in Z \)  and not all having a common factor.

Let \(\mathbb{F}_2\) denote the field of two elements, and let \(\overline{S} \subseteq \mathbb{F}_2^n\) be the reductions modulo 2 of the points of \(S\). Then any \(t_1, \ldots, t_{k+1} \in \overline{S}\) satisfy a nontrivial linear dependence, because we can take the dependence from the end of the previous paragraph and reduce modulo 2. Hence \(\overline{S}\) is contained in a \(k\)-dimensional subspace of \(\mathbb{F}_{2^n}\), and the latter has cardinality exactly \(2^k\). Thus \(\overline{S}\) has at most \(2^k\) elements, as does \(S\).

Variant (suggested by David Savitt): if  \( \bar{S} \)  contained  \( k+1 \)  linearly independent elements, the  \( (k+1)\times n \)  matrix formed by these would have a nonvanishing maximal minor. The lift of that minor back to R would also not vanish, so S would contain  \( k+1 \)  linearly independent elements.

Third solution: (by Catalin Zara) Let V be a k-dimensional subspace. Form the matrix whose rows are the elements of  \( V \cap Z \) ; by construction, it has row rank at most k. It thus also has column rank at most k; in particular, we can choose k coordinates such that each point of  \( V \cap Z \)  is determined by those k of its coordinates. Since each coordinate of a point in Z can only take two values,  \( V \cap Z \)  can have at most  \( 2^{k} \)  elements.

Remark: The proposers probably did not realize that this problem appeared online about three months before the exam, at http://www.artofproblemsolving.com/Forum/viewtopic.php?t=105991. (It may very well have also appeared even earlier.)

B–5 The answer is 1/16. We have

\[
\int_ {0} ^ {1} x ^ {2} f (x) d x - \int_ {0} ^ {1} x f (x) ^ {2} d x
\]

\[
= \int_ {0} ^ {1} (x ^ {3} / 4 - x (f (x) - x / 2) ^ {2}) d x
\]

\[
\leq \int_ {0} ^ {1} x ^ {3} / 4 d x = 1 / 1 6,
\]

with equality when \( f(x) = x / 2 \).

B-6 First solution: We start with some easy upper and lower bounds on \( a_{n} \). We write \( O(f(n)) \) and \( \Omega(f(n)) \) for functions \( g(n) \) such that \( f(n) / g(n) \) and \( g(n) / f(n) \), respectively, are bounded above. Since \( a_{n} \) is a non-decreasing sequence, \( a_{n+1} - a_{n} \) is bounded above, so \( a_{n} = O(n) \). That means \( a_{n}^{-1/k} = \Omega(n^{-1/k}) \), so

\[
a _ {n} = \Omega \left(\sum_ {i = 1} ^ {n} i ^ {- 1 / k}\right) = \Omega (n ^ {(k - 1) / k}).
\]

In fact, all we will need is that  \( a_{n} \rightarrow \infty \)  as  \( n \rightarrow \infty \) .

By Taylor's theorem with remainder, for \( 1 < m < 2 \) and \( x > 0 \),

\[
| (1 + x) ^ {m} - 1 - m x | \leq \frac {m (m - 1)}{2} x ^ {2}.
\]

Taking  \( m = (k + 1)/k \)  and  \( x = a_{n+1}/a_n = 1 + a_n^{-(k+1)/k} \) , we obtain

\[
\left| a _ {n + 1} ^ {(k + 1) / k} - a _ {n} ^ {(k + 1) / k} - \frac {k + 1}{k} \right| \leq \frac {k + 1}{2 k ^ {2}} a _ {n} ^ {- (k + 1) / k}.
\]

In particular,

\[
\lim _ {n \to \infty} a _ {n + 1} ^ {(k + 1) / k} - a _ {n} ^ {(k + 1) / k} = \frac {k + 1}{k}.
\]

In general, if \( x_{n} \) is a sequence with \( \lim_{n\to \infty}x_n = c \), then also

\[
\lim _ {n \to \infty} \frac {1}{n} \sum_ {i = 1} ^ {n} x _ {i} = c
\]

by Cesaro's lemma. Explicitly, for any \(\varepsilon > 0\), we can find \(N\) such that \(|x_{n} - c| \leq \varepsilon / 2\) for \(n \geq N\), and then

\[
\left| c - \frac {1}{n} \sum_ {i = 1} ^ {n} x _ {i} \right| \leq \frac {n - N}{n} \frac {\varepsilon}{2} + \frac {N}{n} \left| \sum_ {i = 1} ^ {N} (c - x _ {i}) \right|;
\]

for n large, the right side is smaller than  \( \varepsilon \) .

In our case, we deduce that

\[
\lim _ {n \to \infty} \frac {a _ {n} ^ {(k + 1) / k}}{n} = \frac {k + 1}{k}
\]

and so

\[
\lim _ {n \to \infty} \frac {a _ {n} ^ {k + 1}}{n ^ {k}} = \left(\frac {k + 1}{k}\right) ^ {k},
\]