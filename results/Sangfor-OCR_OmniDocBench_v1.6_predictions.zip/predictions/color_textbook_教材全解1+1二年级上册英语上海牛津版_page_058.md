#

教材全解 /+ / 二年级英语(第一学期)

小试牛刀

Read and judge(判断下列句子是否符合所给的情景,用😊或😢表示)

1. 你点着自己的鼻子,你说:This is my ear.

2. 你指着对方的鼻子,你说: This is your nose.

3. 你有一双大眼睛,你说:My eyes are big.

4. 指着自己的红头发,你说:Look. My hair is yellow.

5. 告诉别人,你喜欢苹果,你说: You like apples.

Learn the letters→见教材 P25

<table><tr><td>字母</td><td>音标</td><td>运用</td></tr><tr><td>Kk</td><td>/k/</td><td>$\underline{\text{kite}}$ $\underline{\text{Kitty}}$ $\underline{\text{kiss}}$ $\underline{\text{milk}}$ $\underline{\text{look}}$ $\underline{\text{black}}$ $\underline{\text{stick}}$ $\underline{\text{duck}}$ $\underline{\text{sock}}$</td></tr><tr><td>Ll</td><td>/l/</td><td>$\underline{\text{lion}}$ $\underline{\text{light}}$ $\underline{\text{leg}}$ $\underline{\text{lemon}}$ $\underline{\text{listen}}$ $\underline{\text{lovely}}$ $\underline{\text{live}}$ $\underline{\text{like}}$ $\underline{\text{let}}$</td></tr></table>

Look! ↓ A lion ! ↓ 看! 一头狮子!

Look ! \(\downarrow\) A kite ! \(\downarrow\) 看! 一只风筝!

Look! ↓ A lion and a kite. ↓ 看！一头狮子和一只风筝。

A big lion and a small kite. ↓一头大狮子和一只小风筝。

词汇清单

<table><tr><td>单词</td><td>音标</td><td>词性</td><td>词义</td><td>运用</td></tr><tr><td>kite</td><td>/kaɪt/</td><td>n.</td><td>风筝</td><td>I can fly a kite. 我会放风筝。</td></tr><tr><td>lion</td><td>/ˈlaɪən/</td><td>n.</td><td>狮子</td><td>Look at the lion. It’s so big. 看这头狮子,它好大。</td></tr></table>

互动学习

重点讲解·吃透教材

认读和书写: Kk 和 Ll 并掌握其基本读音

指点迷津·提升能力

字母 K 的发音是清辅音 /k/, 声带不振动。发音时舌后部隆起紧贴软腭, 憋住气, 然后突然分开, 气流送出口腔, 形成爆破音。

字母 L 的发音是 /l/，舌端齿

54

关注微信公众号“教辅资料站”获取更多学习资料