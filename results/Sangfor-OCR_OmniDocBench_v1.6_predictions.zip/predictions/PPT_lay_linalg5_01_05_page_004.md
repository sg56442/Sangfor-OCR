HOMOGENEOUS LINEAR SYSTEMS

\[
\left[ \begin{array}{r r r r} 3 & 5 & - 4 & 0 \\ - 3 & - 2 & 4 & 0 \\ 6 & 1 & - 8 & 0 \end{array} \right] \sim \left[ \begin{array}{r r r r} 3 & 5 & - 4 & 0 \\ 0 & 3 & 0 & 0 \\ 0 & - 9 & 0 & 0 \end{array} \right] \sim \left[ \begin{array}{r r r r} 3 & 5 & - 4 & 0 \\ 0 & 3 & 0 & 0 \\ 0 & 0 & 0 & 0 \end{array} \right]
\]

Since \( x_{3} \) is a free variable, Ax = 0 has nontrivial solutions (one for each choice of \( x_{3} \).)

■ Continue the row reduction of [A 0] to reduced echelon form: \(\left[ \begin{array}{ccccc}1 & 0 & 4 & 0 \end{array} \right]\) 4

\[
\left[ \begin{array}{c c c c} 1 & 0 & - \frac {4}{3} & 0 \\ 0 & 1 & 0 & 0 \\ 0 & 0 & 0 & 0 \end{array} \right]
\]

\[
x _ {1} - \frac {4}{3} x _ {3} = 0
\]

\[
x _ {2} = 0
\]

\[
0 = 0
\]

© 2016 Pearson Education, Inc.

Slide 1.5- 4