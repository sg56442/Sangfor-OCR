Result Parameter Details

Peripheral Control Status

The SMPC outputs the peripheral control status to the status register (SR) when the SMPC control mode is used. The status register (SR) is a register that can be read without regard for the INTBACK command. However, when the register is read when the INTBACK command is not in use, all bits except the RESB bit will be undefined.

<table><tr><td rowspan="2">SR</td><td colspan="7">bit7</td><td>bit0</td></tr><tr><td>1</td><td>PDL</td><td>NPE</td><td>RESB</td><td>P2MD1</td><td>P2MD0</td><td>P1MD1</td><td>P1MD0</td></tr><tr><td colspan="9"></td></tr><tr><td colspan="9">P1MD: Port 1 Mode00: 15-byte mode (Returns peripheral data up to a maximum of 15 bytes.)01: 255-byte mode (Returns peripheral data up to a maximum of 255 bytes.)10: Unused11: 0-byte mode (Port is not accessed.)</td></tr><tr><td colspan="9">P2MD: Port 2 Mode00: 15-byte mode (Returns peripheral data up to a maximum of 15 bytes.)01: 255-byte mode (Returns peripheral data up to a maximum of 255 bytes.)10: Unused11: 0-byte mode (Port is not accessed.)</td></tr><tr><td colspan="9">RESB: Reset Button Status Bit0: Reset Button OFF1: Reset Button ONReading without regard for INTBACK command is possible. (Shows status for each V-BLANK-IN.)</td></tr><tr><td colspan="9">NPE: Remaining Peripheral Existence Bit0: No remaining data1: Remaining data</td></tr><tr><td colspan="9">PDL: Peripheral Data Location Bit0: 2nd or above peripheral data1: 1st peripheral data</td></tr><tr><td colspan="9">bit7: Always 1</td></tr></table>

Figure 3.13 Peripheral Control Status

66